/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","ug",{title:"ئىشلەتكۈچى ئارايۈزى رەڭ تاللىغۇچ",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"ئالدىن بەلگىلەنگەن رەڭلەر",config:"بۇ ھەرپ تىزىقىنى config.js ھۆججەتكە چاپلايدۇ"});