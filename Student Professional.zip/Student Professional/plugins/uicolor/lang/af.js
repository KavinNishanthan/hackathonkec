/*
 Copyright (c) 2003-2018, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang("uicolor","af",{title:"UI kleur keuse",options:"Color Options",highlight:"Highlight",selected:"Selected Color",predefined:"Voordefinieerte kleur keuses",config:"Voeg hierdie in jou config.js lêr in"});